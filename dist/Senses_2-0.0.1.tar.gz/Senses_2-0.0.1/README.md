# Senses_2
Senses_2 is a python library which can be used to make give your python program the ability to speak and listen.

Senses_2 can also be used to greet the user.

## How to install this project
1. Open your terminal 
2. Type `pip install Senses_2` and hit enter

## How to use this project
   type `.wish()` to wish good morning, good afternoon or good evening
   type `.speak()` to speak
   type `.listen()` to listen
   
## Example
```
import Senses_2
Senses_2.wish()
```

```
import Senses_2
Senses_2.speak()
```

```
import Senses_2
Senses_2.listen()
```